import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title="UAE E-Commerce Fraud Intelligence", page_icon="🛡️", layout="wide")
DEFAULT_FILE = "uae_ecom_fraud_100k.csv"

@st.cache_data
def make_demo_data(n=100_000, seed=42):
    rng = np.random.default_rng(seed)
    fraud = np.zeros(n, dtype=np.int8)
    fraud[rng.choice(n, 8211, replace=False)] = 1
    dates = pd.date_range("2024-01-01", "2024-12-31 23:59:59", periods=n, tz="UTC")
    methods = ["card", "apple_pay", "google_pay", "paypal", "bank_transfer"]
    cities = ["Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Ras Al Khaimah", "Fujairah"]
    cats = ["electronics", "fashion", "home", "beauty", "grocery", "travel"]
    amount = rng.lognormal(4.2, 0.9, n) * np.where(fraud == 1, 1.35, 1.0)
    return pd.DataFrame({
        "transaction_id": [f"DEMO-{i:06d}" for i in range(1, n+1)],
        "timestamp_utc": dates,
        "amount_aed": np.round(np.clip(amount, 5, 15000), 2),
        "payment_method": rng.choice(methods, n, p=[.48, .18, .12, .14, .08]),
        "shipping_city": rng.choice(cities, n),
        "merchant_category": rng.choice(cats, n),
        "device_type": rng.choice(["mobile", "desktop", "tablet"], n, p=[.68, .25, .07]),
        "browser": rng.choice(["Chrome", "Safari", "Edge", "Firefox"], n),
        "bin_country": rng.choice(["AE", "SA", "IN", "GB", "US"], n),
        "ip_risk_score": np.round(np.where(fraud == 1, rng.uniform(.55, 1, n), rng.uniform(0, .75, n)), 3),
        "transactions_last_1h": rng.poisson(np.where(fraud == 1, 2.8, .8), n),
        "transactions_last_24h": rng.poisson(np.where(fraud == 1, 6.5, 2.2), n),
        "is_fraud": fraud,
        "data_source": "synthetic_demo_generated_in_app"
    })

@st.cache_data
def read_csv(file):
    return pd.read_csv(file)

st.title("🛡️ UAE E-Commerce Fraud Intelligence Dashboard")
st.caption("Management dashboard | Fraud analytics, transaction performance and risk monitoring")

with st.sidebar:
    st.header("Data source")
    mode = st.radio("Choose data source", ["Built-in demo data (no CSV required)", "Upload my CSV"])
    uploaded = st.file_uploader("Upload transaction CSV", type=["csv"]) if mode == "Upload my CSV" else None
    if mode.startswith("Built-in"):
        st.info("Synthetic demo data is generated in memory. No CSV file is needed.")

if mode.startswith("Built-in"):
    df = make_demo_data()
    source = "Built-in synthetic demo data (100,000 rows)"
elif uploaded is not None:
    try:
        df = read_csv(uploaded)
        source = f"Uploaded: {uploaded.name}"
    except Exception as e:
        st.error(f"CSV loading failed: {e}")
        st.stop()
elif Path(DEFAULT_FILE).exists():
    df = read_csv(DEFAULT_FILE)
    source = f"Local file: {DEFAULT_FILE}"
else:
    st.info("Upload a CSV or switch to Built-in demo data.")
    st.stop()

required = {"amount_aed", "is_fraud"}
if not required.issubset(df.columns):
    st.error(f"CSV must contain: {', '.join(required)}")
    st.stop()

df = df.copy()
df["amount_aed"] = pd.to_numeric(df["amount_aed"], errors="coerce")
df["is_fraud"] = pd.to_numeric(df["is_fraud"], errors="coerce")
df = df.dropna(subset=["amount_aed", "is_fraud"])
df = df[df["is_fraud"].isin([0, 1])]
df["is_fraud"] = df["is_fraud"].astype(int)
date_col = next((c for c in ["timestamp_utc", "transaction_date", "date"] if c in df.columns), None)
if date_col:
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce", utc=True)

with st.sidebar:
    st.divider()
    st.header("Dashboard filters")
    st.caption(source)
    filtered = df.copy()
    if date_col and df[date_col].notna().any():
        valid = df[date_col].dropna()
        date_range = st.date_input("Transaction date range",
            value=(valid.min().date(), valid.max().date()),
            min_value=valid.min().date(), max_value=valid.max().date())
        if isinstance(date_range, tuple) and len(date_range) == 2:
            filtered = filtered[filtered[date_col].dt.date.between(*date_range)]
    for col, label in [("payment_method", "Payment method"), ("shipping_city", "Shipping city"),
                       ("merchant_category", "Merchant category"), ("device_type", "Device type")]:
        if col in filtered.columns:
            choices = sorted(filtered[col].dropna().astype(str).unique())
            selected = st.multiselect(label, choices)
            if selected:
                filtered = filtered[filtered[col].astype(str).isin(selected)]

if filtered.empty:
    st.warning("No transactions match the selected filters.")
    st.stop()

if mode.startswith("Built-in"):
    st.warning("DEMO MODE: These 100,000 transactions are synthetic examples, not actual UAE market data.")

n = len(filtered)
frauds = int(filtered["is_fraud"].sum())
rate = frauds / n
gtv = filtered["amount_aed"].sum()
aov = filtered["amount_aed"].mean()
st.caption(f"Data source: {source} | Filtered transactions: {n:,}")
a,b,c,d,e = st.columns(5)
a.metric("Transactions", f"{n:,}")
b.metric("Fraud-labelled transactions", f"{frauds:,}")
c.metric("Historical fraud rate", f"{rate:.2%}")
d.metric("Gross transaction value", f"AED {gtv:,.2f}")
e.metric("Average order value", f"AED {aov:,.2f}")

left,right = st.columns(2)
with left:
    st.subheader("Transaction outcomes")
    counts = pd.DataFrame({"Outcome":["Non-fraud label","Fraud label"],
        "Transactions":[int((filtered.is_fraud==0).sum()),frauds]})
    st.plotly_chart(px.pie(counts,names="Outcome",values="Transactions",hole=.5),use_container_width=True)
with right:
    st.subheader("Transaction value by outcome")
    vals = filtered.assign(Outcome=np.where(filtered.is_fraud==1,"Fraud label","Non-fraud label")).groupby("Outcome",as_index=False).amount_aed.sum()
    st.plotly_chart(px.bar(vals,x="Outcome",y="amount_aed",labels={"amount_aed":"GTV (AED)"}),use_container_width=True)

if date_col and filtered[date_col].notna().any():
    st.subheader("Monthly transaction and fraud trends")
    tmp=filtered.dropna(subset=[date_col]).copy()
    tmp["month"]=tmp[date_col].dt.to_period("M").astype(str)
    monthly=tmp.groupby("month",as_index=False).agg(transactions=("is_fraud","size"),fraud_cases=("is_fraud","sum"),gtv_aed=("amount_aed","sum"))
    monthly["fraud_rate"]=monthly.fraud_cases/monthly.transactions
    x,y=st.columns(2)
    with x:
        st.plotly_chart(px.line(monthly,x="month",y=["transactions","fraud_cases"],markers=True,title="Monthly transaction volume"),use_container_width=True)
    with y:
        fig=px.line(monthly,x="month",y="fraud_rate",markers=True,title="Monthly historical fraud-label rate")
        fig.update_yaxes(tickformat=".1%")
        st.plotly_chart(fig,use_container_width=True)

st.subheader("Fraud patterns by business dimension")
dims=[c for c in ["payment_method","shipping_city","merchant_category","device_type","browser","bin_country"] if c in filtered.columns]
if dims:
    dim=st.selectbox("Select dimension",dims)
    seg=filtered.groupby(dim,dropna=False).agg(transactions=("is_fraud","size"),fraud_cases=("is_fraud","sum"),gtv_aed=("amount_aed","sum")).reset_index()
    seg["fraud_rate"]=seg.fraud_cases/seg.transactions
    fig=px.bar(seg.sort_values("fraud_rate",ascending=False).head(20),x=dim,y="fraud_rate",hover_data=["transactions","fraud_cases","gtv_aed"])
    fig.update_yaxes(tickformat=".1%")
    st.plotly_chart(fig,use_container_width=True)

st.subheader("Transaction investigation table")
cols=[c for c in ["transaction_id","timestamp_utc","amount_aed","payment_method","shipping_city","merchant_category","ip_risk_score","transactions_last_1h","transactions_last_24h","is_fraud"] if c in filtered.columns]
st.dataframe(filtered[cols].sort_values("amount_aed",ascending=False).head(500),use_container_width=True,hide_index=True)
st.download_button("Download filtered transactions",filtered.to_csv(index=False).encode("utf-8"),"uae_fraud_filtered_transactions.csv","text/csv")

with st.expander("Definitions and limitations"):
    st.markdown("- Fraud labels are historical labels, not live model predictions.\n- GTV is not automatically platform revenue.\n- Fraud-labelled transaction value is not confirmed financial loss.\n- Built-in data is synthetic and is for software testing only.\n- This dashboard does not approve, decline or block transactions.")
st.caption("Fraud Intelligence PoC | Management demonstration only")
