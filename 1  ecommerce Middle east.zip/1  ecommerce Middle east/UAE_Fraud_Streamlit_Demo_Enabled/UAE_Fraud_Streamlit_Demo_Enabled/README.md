# UAE E-Commerce Fraud Intelligence Dashboard

The app defaults to built-in synthetic demo data (100,000 rows), generated in memory. No CSV upload is required.

Run on Windows:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

To use a real/approved dataset, select **Upload my CSV** in the sidebar. Required columns: `amount_aed`, `is_fraud` (0/1). Optional date fields: `timestamp_utc`, `transaction_date`, `date`.

**Limitations:** built-in demo data is synthetic, not actual UAE market data. Fraud labels are not live model predictions. GTV is not recognized revenue. This is a proof of concept.
